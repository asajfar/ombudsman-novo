<?php  ?>
<div class="pozadina">
	<div class="container prostor">
		<div class="nslogo">
			<img src="images/logo/ombudsman-logo.png" alt="">						
		</div>
		<div class="naziv">
			<span>Покрајински заштитник грађана - ОМБУДСМАН</span>						
		</div>
		<div class="navbar-header">
			<!-- Dugme za meni na mobilnom - Pocetak -->
			<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<!-- Dugme za meni na mobilnom - Pocetak -->
			<!-- <a class="navbar-brand" href="index.html"><img alt="" src="images/logo.png">Savet za koordinaciju poslova bezbednosti saobraćaja na putevima na teritoriji Grada Novog Sada</a> -->
			
		</div>				    
	</div>
</div>
<?php  ?>