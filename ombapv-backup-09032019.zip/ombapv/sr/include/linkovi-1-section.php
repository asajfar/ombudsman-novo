<?php  ?>

<!-- linkovi-1-section
				================================================== -->
			<div class="section-content services-section linkovi">

				<div class="services-box3 linkovi-1">
					<div class="container">
						<div class="row">

							<!-- <div class="col-md-3">
								<div class="services-post triggerAnimation animated" data-animate="fadeInLeft">
									<span><i class="icon-piechart"></i></span>
									<div class="services-content">
										<h2>НАША ИСТРАЖИВАЊА</h2>
										<a href="#" class="button-linkovi-1">Опширније</a>
									</div>
								</div>
							</div> -->

							<div class="col-md-3">
								<a href="istrazivanja.php" class="linkovi-1-link">
									<div class="services-post triggerAnimation animated" data-animate="fadeInUp">
										<span><i class="icon-piechart"></i></span>
										<div class="services-content">
											<h2>НАША ИСТРАЖИВАЊА</h2>
											<p>Упознајте са са нашим најновијим истраживањима и њховим резултатима.</p>
										</div>
									</div>
								</a>
							</div>

							<div class="col-md-3">
								<a href="izvestaji.php" class="linkovi-1-link">
									<div class="services-post triggerAnimation animated" data-animate="fadeInUp">
										<span><i class="icon-documents"></i></span>
										<div class="services-content">
											<h2>ГОДИШЊИ ИЗВЕШТАЈИ</h2>
											<p>Преузмите и прочитајте све наше до сада објављене годишње извештаје.</p>
										</div>
									</div>
								</a>
							</div>

							<div class="col-md-3">
								<a href="izvestaji.php" class="linkovi-1-link">
									<div class="services-post triggerAnimation animated" data-animate="fadeInUp">
										<span><i class="icon-focus"></i></span>
										<div class="services-content">
											<h2>ИНФОРМАТОР О РАДУ</h2>
											<p>Информисање јавности о документима и информацијама којима располаже Покрајински заштитник грађана - омбудсман.</p>
										</div>
									</div>
								</a>
							</div>

							<div class="col-md-3">
								<a href="akt.php" class="linkovi-1-link">
									<div class="services-post triggerAnimation animated" data-animate="fadeInUp">
										<span><i class="icon-document"></i></span>
										<div class="services-content">
											<h2>ОСНИВАЧКИ АКТ</h2>
											<p>Поктајинска скупштинска одлука о Покрајинском заштитнику грађана - омбудсману.</p>
										</div>
									</div>
								</a>
							</div>

						</div>
					</div>
				</div>
			</div>