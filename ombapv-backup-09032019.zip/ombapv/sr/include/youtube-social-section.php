<?php  ?>

<!-- YouTube and Facebook section ========================================================================= -->
			<div class="section-content about-section dark-grey-background">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="triggerAnimation animated fadeInRight" data-animate="fadeInRight" style="">
								<iframe width="100%" height="315" src="https://www.youtube.com/embed/videoseries?list=PLfBL1Fp_S286yjOzOYoEzDqTi1XqfYJqs" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
							</div>
						</div>
						<div class="col-md-6">
							<div class="center">
							  <div id="social-test">
								  <ul class="social">
								    <li><a href="https://www.facebook.com/pg/ombudsmanapv" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								    <li><a href="https://twitter.com/ombudsmanapv" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								    <li><a href="https://www.instagram.com/ombudsmanapv" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
								    <li><a href="https://www.youtube.com/channel/UC3ItgmtAMf8b5ByR8fDys5A" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
								  </ul>
							  </div>
							</div>
						</div>
					</div>
				</div>
			</div>