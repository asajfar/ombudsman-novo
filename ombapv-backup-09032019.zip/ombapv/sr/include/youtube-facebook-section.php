<?php  ?>

<!-- YouTube and Facebook section ========================================================================= -->
			<div class="section-content about-section grey-background">
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<div class="triggerAnimation animated fadeInRight" data-animate="fadeInRight" style="">
								<iframe width="100%" height="315" src="https://www.youtube.com/embed/videoseries?list=PLfBL1Fp_S286yjOzOYoEzDqTi1XqfYJqs" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
							</div>
						</div>
						<div class="col-md-6">
							<div class="triggerAnimation animated fadeInLeft" data-animate="fadeInLeft" style="">
								<div class="fb-page" data-href="https://www.facebook.com/ombudsmanapv/" data-tabs="timeline" data-width="500" data-height="315" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/ombudsmanapv/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/ombudsmanapv/">Pokrajinski zaštitnik građana - ombudsman</a></blockquote></div>
							</div>
						</div>
					</div>
				</div>
			</div>