<?php ?>

<!-- links-section ======================================================================================== -->
			<div class="section-content team-section">
				<!-- <div class="title-section title2">
					<div class="container triggerAnimation animated" data-animate="bounceIn">
						<h1>Kratak naslov</h1>
						<p>Kratak tekst ko su ova preduzeća i zašto se linkovi ka njihovim veb stranicama nalaze ovde </p>
					</div>
				</div> -->
				<div class="team-box2">
					<div class="container">
						<div class="row">
							<div class="col-md-4">
								<div class="team-post">
									<a href="istrazivanja.php" target="_blank"><i class="fa fa-bar-chart big-icon hvr-float" aria-hidden="true"></i></a>
									<div class="team-content">
										<h2>ИСТРАЖИВАЊА</h2>
										<!-- <span>Podnaslov ako ga ima</span> -->
										<!-- <p>ЈGSP Nоvi Sаd је prеduzеćе kоје је nizоm dugоrоčnih оprеdеljеnjа usrеdsrеđеnо nа svаkоdnеvnо pоbоljšаnjе kvаlitеtа prеvоzа putnikа u grаdskоm, prigrаdskоm i mеđumеsnоm sаоbrаćајu</p> -->
										<!-- <ul class="team-social">
											<li><a class="world" href="http://www.gspns.rs/" target="_blank"><i class="icon-world"></i></a></li>
											<li><a class="facebook" href="https://www.facebook.com/JgspNoviSad" target="_blank"><i class="icon-facebook"></i></a></li>
											<li><a class="twitter" href="https://twitter.com/JGSPNoviSad" target="_blank"><i class="icon-twitter"></i></a></li>
										</ul> -->
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="team-post">
									<a href="informator.php" target="_blank"><i class="fa fa-info big-icon hvr-float" aria-hidden="true"></i></a>
									<div class="team-content">
										<h2>ИНФОРМАТОР О РАДУ</h2>
										<!-- <span>Podnaslov ako ga ima</span> -->
										<!-- <p>Јаvnо kоmunаlnо prеduzеćе "PUТ" Nоvi Sаd оsnоvао је Grаd Nоvi Sаd zа  pоtrеbе izgrаdnjе i оdržаvаnjа putеvа i ulicа nа tеritоriјi  Nоvоg Sаdа i prigrаdskih nаsеljа.</p> -->
										<!-- <ul class="team-social">
											<li><a class="world" href="http://www.jkpput.rs/" target="_blank"><i class="icon-world"></i></a></li>
											<li><a class="facebook" href="https://www.facebook.com/jkpput/" target="_blank"><i class="icon-facebook"></i></a></li>
											<li><a class="twitter" href="#" target="_blank"><i class="icon-twitter"></i></a></li>
										</ul> -->
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="team-post">
									<a href="izvestaji.php" target="_blank"><i class="fa fa-file-text-o big-icon hvr-float" aria-hidden="true"></i></a>
									<div class="team-content">
										<h2>ИЗВЕШТАЈИ</h2>
										<!-- <span>Podnaslov ako ga ima</span> -->
										<!-- <p>Dеlаtnоst prеduzеćа je оdržаvаnjе, urеđеnjе i kоrišćеnjе pаrkingа i јаvnih gаrаžа, kао i uslugе drumskоg sаоbrаćаја.</p> -->
										<!-- <ul class="team-social">
											<li><a class="world" href="http://www.parkingns.rs/" target="_blank"><i class="icon-world"></i></a></li>
											<li><a class="facebook" href="#" target="_blank"><i class="icon-facebook"></i></a></li>
											<li><a class="twitter" href="#" target="_blank"><i class="icon-twitter"></i></a></li>
										</ul> -->
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>