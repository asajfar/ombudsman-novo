<?php die('Direct call - access denied'); ?>
YToxOntzOjI6ImlkIjthOjE6e2k6MTU0OTQ1NjE0NDtzOjk6Im9tYnVkc21hbiI7fX0=