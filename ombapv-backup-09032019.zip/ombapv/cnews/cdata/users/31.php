<?php die('Direct call - access denied'); ?>
YToxOntzOjU6ImVtYWlsIjthOjE6e3M6MTc6ImFzYWpmYXJAZ21haWwuY29tIjtzOjc6ImFzYWpmYXIiO319