<?php die('Direct call - access denied'); ?>
YToxOntzOjQ6Im5hbWUiO2E6MTp7czo0OiJBbGVuIjthOjE6e3M6MzoiYmFuIjtzOjEwOiIxNTM2MjIzMDI2Ijt9fX0=