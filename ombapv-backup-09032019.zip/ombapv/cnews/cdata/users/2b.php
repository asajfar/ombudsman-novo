<?php die('Direct call - access denied'); ?>
YToxOntzOjI6ImlkIjthOjE6e2k6MTUxOTMyOTE2NjtzOjc6ImFzYWpmYXIiO319