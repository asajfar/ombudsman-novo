<?php die('Direct call - access denied'); ?>
YToxOntzOjU6ImVtYWlsIjthOjE6e3M6MjM6Im9mZmljZUBvbWJ1ZHNtYW5hcHYub3JnIjtzOjk6Im9tYnVkc21hbiI7fX0=