<?php die('Direct call - access denied'); ?>
YTowOnt9