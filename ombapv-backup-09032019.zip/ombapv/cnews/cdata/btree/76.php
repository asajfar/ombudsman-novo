<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI3NjQ3OTY2YjczNDNjMjkwNDg2NzMyNTJlNDkwZjczNiI7aToxNTQ5NDU3NjI0O319