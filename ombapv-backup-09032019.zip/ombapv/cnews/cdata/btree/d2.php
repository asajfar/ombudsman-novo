<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJkMmRkZWExOGYwMDY2NWNlODYyM2UzNmJkNGUzYzdjNSI7aToxNTQ1NDAxMTQzO319