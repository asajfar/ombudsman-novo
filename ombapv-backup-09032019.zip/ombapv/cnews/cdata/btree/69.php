<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6IjY5Nzg5N2FlYjQ2NDMwNWE5ZTFlZTE2MDI5ZjAwM2I5IjtpOjE1NDE2MDAzNjE7fX0=