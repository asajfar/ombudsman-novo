<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI5ZDkyNjllN2YzODZiYzUyZTkwZjQ5YmEyYTA1NDBiZCI7aToxOTt9fQ==