<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjA6e319