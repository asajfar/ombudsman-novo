<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiJmYWJiMWIzOTdjOWIyZTVjYWNhNjllYjQ1ZWQ5MGMzZCI7aToyODt9czo1OiJ0c19wZyI7YTowOnt9fQ==