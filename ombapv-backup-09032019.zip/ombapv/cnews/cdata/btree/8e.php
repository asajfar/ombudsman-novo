<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI4ZTI5NmEwNjdhMzc1NjMzNzBkZWQwNWY1YTNiZjNlYyI7aToxNTI5OTk2MzU3O319