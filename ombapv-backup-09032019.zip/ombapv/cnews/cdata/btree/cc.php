<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiJjYzM5Yjc2ZThjOWE2ZTVkOTM1NmQ3ZjFmODk5ZGE4ZSI7aTo0ODt9czo1OiJ0c19wZyI7YTowOnt9fQ==