<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJhZDYxYWIxNDMyMjNlZmJjMjRjN2QyNTgzYmU2OTI1MSI7aToxNTQ1NjYwNjA3O319