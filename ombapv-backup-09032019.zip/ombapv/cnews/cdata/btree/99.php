<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YTowOnt9czo1OiJ0c19wZyI7YTowOnt9fQ==