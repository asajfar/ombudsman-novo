<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiIwMWE3MTlhYmE4MDUxNjFlYWNiMWVjYzMxYWNlNGE3MiI7aToxMDt9fQ==