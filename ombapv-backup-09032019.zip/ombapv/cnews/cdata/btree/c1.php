<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJjMTZhNTMyMGZhNDc1NTMwZDk1ODNjMzRmZDM1NmVmNSI7aToxNTM2OTM1MTA5O319