<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJmMDMzYWIzN2MzMDIwMWY3M2YxNDI0NDlkMDM3MDI4ZCI7aToxNTQ3ODEzODUwO319