<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI5ZTg3NTc3MGFhZmJhMDlkZTRjNWRlNTViYzgwNWUxZCI7aTo0OTt9czo1OiJ0c19wZyI7YTowOnt9fQ==