<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI2NTEyYmQ0M2Q5Y2FhNmUwMmM5OTBiMGE4MjY1MmRjYSI7aToxNDkxMjQ4Njg2O319