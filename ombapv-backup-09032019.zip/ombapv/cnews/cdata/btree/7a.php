<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI3YWRiYjAyMjgzZWE2ZmM1ODhhODg0ZTA1ZTk0Mjk3MiI7aToxNzt9czo1OiJ0c19wZyI7YTowOnt9fQ==