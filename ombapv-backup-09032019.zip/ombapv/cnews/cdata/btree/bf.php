<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiJiZmFjMzhlY2QxZDRmY2YwMGZjZWEwN2ZlZGUxMmQ4YiI7aTozMjt9czo1OiJ0c19wZyI7YTowOnt9fQ==