<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiIwNzJiMDMwYmExMjZiMmY0YjIzNzRmMzQyYmU5ZWQ0NCI7aToxNTQzODQxNjgyO319