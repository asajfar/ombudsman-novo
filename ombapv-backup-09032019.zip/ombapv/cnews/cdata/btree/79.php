<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI3OTZjNTIzNDIzZjc1ZWU3NDJjMTVmNWNhMjJkMmNkZiI7aToyMTt9czo1OiJ0c19wZyI7YTowOnt9fQ==