<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI3NzZmNzk1NDI4YmQyYzMyZTNmMjU0MzE2M2JmMWI4YiI7aTo2NDt9fQ==