<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI5Nzc4ZDVkMjE5YzUwODBiOWE2YTE3YmVmMDI5MzMxYyI7aToxNTQ4OTQwMTI5O319