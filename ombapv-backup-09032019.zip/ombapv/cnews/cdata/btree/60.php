<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6IjYwYjE4YmFkMjY3ZTFkZTljNmI4Y2FhZTZkNTM5ODliIjtpOjE1NDU0MDExNDM7fX0=