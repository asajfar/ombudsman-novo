<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJmNzE3NzE2M2M4MzNkZmY0YjM4ZmM4ZDI4NzJmMWVjNiI7aToxNTM5Nzc3MDc0O319