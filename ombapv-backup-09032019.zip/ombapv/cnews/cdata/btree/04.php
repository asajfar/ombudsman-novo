<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiIwNDcxYTI0N2RlMGQxYWI1NWVmYTZjMWQwMmMxOWQwMyI7aTo2O319