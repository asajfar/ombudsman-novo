<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6Ijk2OWVmYzBhMTEwMmIzZDk4ZDVhYTcyYTFjNjRlMjUyIjtpOjE1NDUxNDc5Njc7fX0=