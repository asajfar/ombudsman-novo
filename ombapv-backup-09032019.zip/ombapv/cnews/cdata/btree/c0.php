<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJjMGM3Yzc2ZDMwYmQzZGNhZWZjOTZmNDAyNzViZGMwYSI7aToxNTQwOTk2NzQ2O319