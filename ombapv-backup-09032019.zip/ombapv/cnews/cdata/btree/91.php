<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI5MWExZjAzNTJjMDFjNzlmNmQxZjVhMDQ5MmYwOTA2MiI7aToyO31zOjU6InRzX3BnIjthOjA6e319