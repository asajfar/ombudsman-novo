<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI1ZTU1MzE0MTdlOGNjZTI4ZjI0Y2UxYjc5OTZjNDZhZSI7aToyMjt9fQ==