<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiIyNjgzMWJjYzhlOWVlMzY1NGZkZmFjYzU3YjBiYzFmNSI7aTo2Mzt9fQ==