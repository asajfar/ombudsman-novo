<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiIzZWY4MTU0MTZmNzc1MDk4ZmU5NzcwMDQwMTVjNjE5MyI7aToxNDQ4MTk5NDcwO319