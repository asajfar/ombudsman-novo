<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJhODdmZjY3OWEyZjNlNzFkOTE4MWE2N2I3NTQyMTIyYyI7aToxNTE3NDk3NDM4O319