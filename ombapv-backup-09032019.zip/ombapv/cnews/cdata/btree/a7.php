<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiJhNzFkMmEwZWU3MGY5OWQ4MDBjNWFlYmY3MDM1NDJkZiI7aToxODt9czo1OiJ0c19wZyI7YTowOnt9fQ==