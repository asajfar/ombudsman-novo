<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiIyM2EzZTk5MzM2M2IwYjNkNGMzZTA0MzhjNGRmZWY1MCI7aTo2Mjt9fQ==