<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJjNTFjZTQxMGMxMjRhMTBlMGRiNWU0Yjk3ZmMyYWYzOSI7aToxNTI4ODE0NTk0O319