<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiJiMjA4NTY2YTI1OGM1NzFkNTVhZDBhNGE4Y2I4YjEzZiI7aToyNDt9czo1OiJ0c19wZyI7YTowOnt9fQ==