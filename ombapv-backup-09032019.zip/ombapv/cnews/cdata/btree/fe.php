<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJmZTlmYzI4OWMzZmYwYWYxNDJiNmQzYmVhZDk4YTkyMyI7aToxNTQ4MjQ5ODY0O319