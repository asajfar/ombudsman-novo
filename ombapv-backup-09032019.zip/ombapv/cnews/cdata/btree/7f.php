<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI3ZjM5ZjgzMTdmYmRiMTk4OGVmNGM2MjhlYmEwMjU5MSI7aToxNTQzODUwNDM0O319