<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJmYmQ3OTM5ZDY3NDk5N2NkYjQ2OTJkMzRkZTg2MzNjNCI7aToxNTQ1OTg5NTUyO319