<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6ImYzM2IyNTdkZjQzOTEwZGY4YTFmN2ZkZDAwMzhiMThjIjtpOjE1NDUzOTM2NjY7fX0=