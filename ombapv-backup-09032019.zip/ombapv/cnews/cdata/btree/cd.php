<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiJjZGVlYWM3Y2EyZjI5YTg3ZGVlNTYyMWQ2Mjc2NzU3ZCI7aToxMjt9fQ==