<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI2OGQzMGE5NTk0NzI4YmMzOWFhMjRiZTk0YjMxOWQyMSI7aToxNTQ4NDI0NDk2O319