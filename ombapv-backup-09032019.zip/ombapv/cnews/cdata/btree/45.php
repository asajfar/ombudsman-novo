<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI0NWM0OGNjZTJlMmQ3ZmJkZWExYWZjNTFjN2M2YWQyNiI7aToxNTIwNjA3ODA0O319