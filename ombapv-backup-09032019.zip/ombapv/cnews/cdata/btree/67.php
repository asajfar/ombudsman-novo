<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI2N2M2YTFlN2NlNTZkM2Q2ZmE3NDhhYjZkOWFmM2ZkNyI7aToxNTQwODE1NDgxO319