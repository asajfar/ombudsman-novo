<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI3MzViOTBiNDU2ODEyNWVkNmMzZjY3ODgxOWI2ZTA1OCI7aToxNTQ0MTkxNjg3O319