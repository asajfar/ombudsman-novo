<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6ImY5YzIyYTU2N2I5MmJlYTRjOGVkNDk3ZmZhYjA0OWVlIjtpOjE1NDQxOTE2ODc7fX0=