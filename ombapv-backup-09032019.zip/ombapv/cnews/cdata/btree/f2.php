<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiJmMjFmODAyNzFlOThlODljMmMzOTllNDBlZDg1YTY1MiI7aTo1O31zOjU6InRzX3BnIjthOjA6e319