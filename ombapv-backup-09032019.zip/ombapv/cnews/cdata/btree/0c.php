<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6IjBjOTZmNGVkOTQ1N2Y1Zjg2MmI4MDkzYzhhNjMyMmE4IjtpOjE1NDk0NTc2MjQ7fX0=