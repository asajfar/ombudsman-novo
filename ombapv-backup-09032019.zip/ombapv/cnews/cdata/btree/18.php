<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiIxODJiZTBjNWNkY2Q1MDcyYmIxODY0Y2RlZTRkM2Q2ZSI7aToxNTM3MTc4MTg0O319