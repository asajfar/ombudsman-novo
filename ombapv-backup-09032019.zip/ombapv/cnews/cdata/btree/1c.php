<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiIxYzM4M2NkMzBiN2MyOThhYjUwMjkzYWRmZWNiN2IxOCI7aToxNTM3NDU0NTU4O319