<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6ImI3M2I2YWMyYjc4YzNmZDY0NDY3M2ZmZDE3MzlkNjBiIjtpOjE1NDI5NjcyMjk7fX0=