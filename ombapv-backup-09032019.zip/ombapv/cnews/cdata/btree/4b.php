<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI0YmQyMmRkOWM0YmM0ZjlhOTFiYTdlZWJjOTc2M2MwZiI7aToyMzt9czo1OiJ0c19wZyI7YTowOnt9fQ==