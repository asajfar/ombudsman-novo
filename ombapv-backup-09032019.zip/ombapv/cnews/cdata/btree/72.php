<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI3MmIzMmExZjc1NGJhMWMwOWIzNjk1ZTBjYjZjZGU3ZiI7aToxNTQzMjM5NDIwO319