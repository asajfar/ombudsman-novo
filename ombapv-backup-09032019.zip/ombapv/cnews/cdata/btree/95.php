<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI5NWQ4OGFhNmI2M2I2OWYzOGM2YjdjMDAyNTBhZDNiZSI7aTozNzt9fQ==