<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI2NDJlOTJlZmI3OTQyMTczNDg4MWI1M2UxZTFiMThiNiI7aToxNTQwNzcyNjE4O319