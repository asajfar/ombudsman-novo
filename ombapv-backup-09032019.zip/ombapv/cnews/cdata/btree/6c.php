<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI2YzgzNDljYzcyNjBhZTYyZTNiMTM5NjgzMWE4Mzk4ZiI7aToxNTM5OTUwMjU1O319