<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6ImViZDE4Y2MyZWY2MGQ1OGE2MDIzMDI1MjFiNWEyNTNlIjtpOjE0NDgxOTk0NzA7fX0=