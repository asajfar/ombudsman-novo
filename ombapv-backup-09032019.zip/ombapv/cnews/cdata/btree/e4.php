<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiJlNGRhM2I3ZmJiY2UyMzQ1ZDc3NzJiMDY3NGEzMThkNSI7aToxNTE4NTM0NDMyO319