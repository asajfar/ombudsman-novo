<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiIwMmU3NGYxMGUwMzI3YWQ4NjhkMTM4ZjJiNGZkZDZmMCI7aToxNTMyOTQ2NzI1O319