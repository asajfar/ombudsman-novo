<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6IjVmYzUwYzJmNDE5YzRhNTYwMGQ1MmM2NDE2NjYwYWUwIjtpOjE1NDI2NDExMzE7fX0=