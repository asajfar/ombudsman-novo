<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI3Y2JiYzQwOWVjOTkwZjE5Yzc4Yzc1YmQxZTA2ZjIxNSI7aToxNTQ0NzkyODY3O319