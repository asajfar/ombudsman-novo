<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiI5OGYxMzcwODIxMDE5NGM0NzU2ODdiZTYxMDZhM2I4NCI7aToxNTEyMTMzMjM5O319