<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiIxNjc5MDkxYzVhODgwZmFmNmZiNWU2MDg3ZWIxYjJkYyI7aToxNTE5MjM2NjIwO319