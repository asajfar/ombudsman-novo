<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiJjM2Q3MDAyZDA0MTU0YzA0NDQxNGFmOGU2YjZkODI1YSI7aToyOTt9czo1OiJ0c19wZyI7YTowOnt9fQ==