<?php die('Direct call - access denied'); ?>
YToxOntzOjY6Im5pZF90cyI7YToxOntzOjMyOiIwOTNmNjVlMDgwYTI5NWY4MDc2YjFjNTcyMmE0NmFhMiI7aToxNTQzNTgyNjAyO319