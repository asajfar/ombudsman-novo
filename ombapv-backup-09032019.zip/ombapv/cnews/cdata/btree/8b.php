<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6IjhiOWFkNGRkYjJiMGRiOWExZTE3ODM2NDJkZTYwMjlkIjtpOjE1NDg4NTY1NzI7fX0=