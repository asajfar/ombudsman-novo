<?php die('Direct call - access denied'); ?>
YToyOntzOjY6Im50c19pZCI7YToxOntzOjMyOiI4OWEyZTE1MzMxYzEyMmY4MGE1Yjc3MDFjODI5ZDY1ZSI7aToxNTt9czo1OiJ0c19wZyI7YTowOnt9fQ==