<?php die('Direct call - access denied'); ?>
YToxOntzOjU6InBnX3RzIjthOjE6e3M6MzI6Ijg0YWEyMDAxNTM2MDRjZjMzMjNjM2M1MTg2MWI3ZDdiIjtpOjE1NDU5ODY0MzQ7fX0=