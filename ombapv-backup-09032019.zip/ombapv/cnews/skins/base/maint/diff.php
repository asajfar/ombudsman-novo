<!-- difference between latest and current cutenews version -->
