<?php  ?>

<!-- linkovi-1-section
				================================================== -->
			<div class="section-content services-section linkovi">

				<div class="services-box3 linkovi-1">
					<div class="container">
						<div class="row">

							<!-- <div class="col-md-4">
								<div class="services-post triggerAnimation animated" data-animate="fadeInLeft">
									<span><i class="icon-piechart"></i></span>
									<div class="services-content">
										<h2>НАША ИСТРАЖИВАЊА</h2>
										<a href="#" class="button-linkovi-1">Опширније</a>
									</div>
								</div>
							</div> -->

							<!-- <div class="col-md-4">
								<a href="istrazivanja.php" class="linkovi-1-link">
									<div class="services-post triggerAnimation animated" data-animate="fadeInUp">
										<span><i class="icon-piechart"></i></span>
										<div class="services-content">
											<h2>OUR INQUIRIES</h2>
											<p>Learn about our latest inquiries and their results.</p>
										</div>
									</div>
								</a>
							</div> -->

							<div class="col-md-4">
								<a href="reports.php" class="linkovi-1-link">
									<div class="services-post triggerAnimation animated" data-animate="fadeInUp">
										<span><i class="icon-documents"></i></span>
										<div class="services-content">
											<h2>ANNUAL REPORTS</h2>
											<p>Download and read all annual reports published so far.</p>
										</div>
									</div>
								</a>
							</div>

							<div class="col-md-4">
								<a href="information-booklet" class="linkovi-1-link">
									<div class="services-post triggerAnimation animated" data-animate="fadeInUp">
										<span><i class="icon-focus"></i></span>
										<div class="services-content">
											<h2>INFORMATION BOOKLET</h2>
											<p>Informing the public on documents and information available to the Provincial Protector of Citizens - Ombudsman</p>
										</div>
									</div>
								</a>
							</div>

							<div class="col-md-4">
								<a href="act.php" class="linkovi-1-link">
									<div class="services-post triggerAnimation animated" data-animate="fadeInUp">
										<span><i class="icon-document"></i></span>
										<div class="services-content">
											<h2>FOUNDING ACT</h2>
											<p>The Provincial Assembly Decision on the Provincial Protector of Citizens - Ombudsman.</p>
										</div>
									</div>
								</a>
							</div>

						</div>
					</div>
				</div>
			</div>